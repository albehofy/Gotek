<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
 public function up(): void
{
    Schema::table('testimonials', function (Blueprint $table) {
        $table->text('feedback')->nullable()->change(); // تعديله ليقبل Null
    });
}

public function down(): void
{
    Schema::table('testimonials', function (Blueprint $table) {
        $table->text('feedback')->nullable(false)->change();
    });
}
};
