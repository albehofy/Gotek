<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\FinanceCategory;
use App\Models\LedgerEntry;
use App\Models\ClientPayment;
use App\Models\CustodyAccount;
use App\Models\FixedAsset;
use App\Models\PayrollRecord;
use App\Models\Department;
use App\Models\Deal;
use App\Models\Task;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class FinanceController extends Controller
{
    // --- Top-Level Dashboard & Accounts Summary ---
    public function summary(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->canAccessFinance()) {
            return response()->json(['message' => 'غير مصرح لك بدخول الإدارة المالية والخزينة (مخصص للسوبر أدمن ومدير الحسابات فقط)'], 403);
        }

        $incomeQuery = LedgerEntry::where('type', 'income');
        $expenseQuery = LedgerEntry::where('type', 'expense');
        $clientPaymentsQuery = ClientPayment::query();

        $deptId = $request->query('department_id');
        if ($deptId) {
            $incomeQuery->where('department_id', $deptId);
            $expenseQuery->where('department_id', $deptId);
        }

        $ledgerIncome = (float) $incomeQuery->sum('amount');
        $paymentsIncome = (float) ClientPayment::sum('amount');
        $tasksIncome = (float) Task::where('status', '!=', 'cancelled')->sum('client_price');
        $totalIncome = max($ledgerIncome, $paymentsIncome, $tasksIncome);

        $totalExpenses = (float) $expenseQuery->sum('amount');
        $netRemainingBalance = max(0, $totalIncome - $totalExpenses);

        // Custody Total Summary
        $activeCustody = CustodyAccount::where('status', 'open')->sum('issued_amount') - CustodyAccount::where('status', 'open')->sum('returned_amount');

        // Assets Total (Super Admin / Admin view)
        $totalFixedAssets = FixedAsset::where('status', 'active')->sum('value');

        // Receivables (Uncollected amounts owed to company by clients)
        $allDeals = Deal::all();
        $totalReceivables = 0;
        foreach ($allDeals as $d) {
            $unpaid = max(0, (float) $d->calculated_total - (float) $d->calculated_paid);
            $totalReceivables += $unpaid;
        }

        // Monthly Obligations (Owed BY company: Base Salaries + Task Earnings + Commissions - Advances - Deductions + Bonuses)
        $employees = User::whereIn('role', ['employee', 'department_manager', 'manager', 'sales', 'admin', 'super_admin', 'account_manager'])->get();
        $totalMonthlyObligations = 0;
        $totalTaskEarnings = 0;
        $totalCommissions = 0;

        foreach ($employees as $employee) {
            $paymentType = $employee->payment_type ?? 'salary_based';
            $baseSalary = (float) $employee->base_salary;

            $completedTasks = $employee->tasks()->whereIn('status', ['done', 'approved', 'completed'])->get();
            $empTaskEarn = 0;
            foreach ($completedTasks as $t) {
                $empTaskEarn += (float) ($t->employee_price ?? $t->client_price ?? 0);
            }
            $totalTaskEarnings += $empTaskEarn;

            $empComm = 0;
            if (in_array($paymentType, ['percentage_based', 'hybrid', 'commission'])) {
                $salesDeals = Deal::where('sales_person_id', $employee->id)->get();
                foreach ($salesDeals as $d) {
                    if ($d->sales_commission_type === 'percentage') {
                        $empComm += ($d->calculated_total * (float) $d->sales_commission_value) / 100;
                    } elseif ($d->sales_commission_type === 'fixed') {
                        $empComm += (float) $d->sales_commission_value;
                    }
                }
            }
            $totalCommissions += $empComm;

            $advances = LedgerEntry::where('employee_id', $employee->id)->where('type', 'expense')->whereHas('category', function($q) { $q->where('name_ar', 'like', '%سلف%'); })->sum('amount');
            $deductions = LedgerEntry::where('employee_id', $employee->id)->where('type', 'expense')->whereHas('category', function($q) { $q->where('name_ar', 'like', '%خصومات%'); })->sum('amount');
            $bonuses = LedgerEntry::where('employee_id', $employee->id)->where('type', 'expense')->whereHas('category', function($q) { $q->where('name_ar', 'like', '%مكافآت%')->orWhere('name_ar', 'like', '%حوافز%'); })->sum('amount');

            $empNet = max(0, $baseSalary + $empTaskEarn + $empComm - $advances - $deductions + $bonuses);
            $totalMonthlyObligations += $empNet;
        }

        return response()->json([
            'status' => 'success',
            'summary' => [
                'total_income' => (float) $totalIncome,
                'total_expenses' => (float) $totalExpenses,
                'net_balance' => (float) $netRemainingBalance,
                'active_custody_float' => (float) $activeCustody,
                'total_fixed_assets' => (float) $totalFixedAssets,
                'company_capital' => (float) ($netRemainingBalance + $totalFixedAssets),
                'total_receivables' => (float) $totalReceivables,
                'monthly_obligations' => (float) $totalMonthlyObligations,
                'total_task_earnings' => (float) $totalTaskEarnings,
                'total_commissions' => (float) $totalCommissions,
            ]
        ]);
    }

    // --- Ledger & Expense Logging ---
    public function getLedger(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->canAccessFinance()) {
            return response()->json(['message' => 'غير مصرح لك بفتح السجل المالي'], 403);
        }

        $query = LedgerEntry::with(['category', 'department', 'deal', 'client', 'employee', 'creator'])->latest();

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->filled('department_id')) {
            $query->where('department_id', $request->department_id);
        }
        if ($request->filled('payment_method')) {
            $query->where('payment_method', $request->payment_method);
        }
        if ($request->filled('from_date')) {
            $query->where('date', '>=', $request->from_date);
        }
        if ($request->filled('to_date')) {
            $query->where('date', '<=', $request->to_date);
        }
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('description', 'like', "%{$search}%")
                  ->orWhereHas('category', function($catQ) use ($search) {
                      $catQ->where('name_ar', 'like', "%{$search}%")
                           ->orWhere('name_en', 'like', "%{$search}%");
                  })
                  ->orWhereHas('client', function($cq) use ($search) {
                      $cq->where('name', 'like', "%{$search}%");
                  })
                  ->orWhereHas('employee', function($eq) use ($search) {
                      $eq->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $entries = $query->paginate($request->get('per_page', 25));
        return response()->json(['status' => 'success', 'data' => $entries]);
    }

    public function storeLedger(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->canAccessFinance()) {
            return response()->json(['message' => 'غير مصرح لك بتسجيل قيود مالية'], 403);
        }
        $validated = $request->validate([
            'date' => 'required|date',
            'type' => 'required|in:income,expense,custody_issued,custody_returned',
            'category_id' => 'nullable|exists:finance_categories,id',
            'department_id' => 'nullable|exists:departments,id',
            'deal_id' => 'nullable|exists:deals,id',
            'client_id' => 'nullable|exists:users,id',
            'employee_id' => 'nullable|exists:users,id',
            'amount' => 'required|numeric|min:0.01',
            'payment_method' => 'required|in:cash,cash_hand,instapay,bank_transfer',
            'description' => 'nullable|string',
            'receipt_path' => 'nullable|string'
        ]);

        $validated['created_by'] = Auth::id();
        $entry = LedgerEntry::create($validated);

        return response()->json(['status' => 'success', 'data' => $entry->load(['category', 'department', 'creator'])], 201);
    }

    // --- Manageable Categories ---
    public function getCategories()
    {
        $categories = FinanceCategory::where('is_active', true)->get();
        return response()->json(['status' => 'success', 'data' => $categories]);
    }

    public function storeCategory(Request $request)
    {
        $validated = $request->validate([
            'name_ar' => 'required|string|max:255',
            'name_en' => 'nullable|string|max:255',
            'type' => 'required|in:expense,income',
        ]);

        $category = FinanceCategory::create($validated);
        return response()->json(['status' => 'success', 'data' => $category], 201);
    }

    // --- Client Partial Payments & Outstanding Balances ---
    public function getClientBalances(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->canAccessFinance()) {
            return response()->json(['message' => 'غير مصرح لك بفتح كشف أرصدة العملاء'], 403);
        }

        $query = User::where(function($q) {
            $q->where('role', 'client')
              ->orWhere('role', 'Client')
              ->orWhereHas('roles', function($rq) {
                  $rq->where('slug', 'client');
              })
              ->orWhereHas('roleModel', function($rq) {
                  $rq->where('slug', 'client');
              });
        });

        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%")
                  ->orWhere('client_code', 'like', "%{$search}%");
            });
        }

        $clients = $query->get();
        $report = [];

        foreach ($clients as $client) {
            $deals = Deal::where('client_id', $client->id)->get();
            $totalBilled = 0;
            $totalPaid = 0;

            foreach ($deals as $deal) {
                $totalBilled += (float) $deal->calculated_total;
                $totalPaid += (float) $deal->calculated_paid;
            }

            $report[] = [
                'id' => $client->id,
                'client_id' => $client->id,
                'client_code' => $client->client_code,
                'is_hold' => (bool) $client->is_hold,
                'client_name' => $client->name,
                'name' => $client->name,
                'client_email' => $client->email,
                'email' => $client->email,
                'phone' => $client->phone,
                'deals_count' => $deals->count(),
                'total_billed' => (float) $totalBilled,
                'total_paid' => (float) $totalPaid,
                'outstanding_balance' => (float) max(0, $totalBilled - $totalPaid)
            ];
        }

        return response()->json(['status' => 'success', 'data' => array_values($report)]);
    }

    public function storeClientPayment(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->canAccessFinance()) {
            return response()->json(['message' => 'غير مصرح لك بتسجيل دفعات مالية أو تحصيلات'], 403);
        }

        // Auto-fill client_id from deal if not passed
        if (!$request->filled('client_id') && $request->filled('deal_id')) {
            $dealTemp = Deal::find($request->deal_id);
            if ($dealTemp && $dealTemp->client_id) {
                $request->merge(['client_id' => $dealTemp->client_id]);
            }
        }

        $validated = $request->validate([
            'deal_id' => 'required|exists:deals,id',
            'client_id' => 'required|exists:users,id',
            'amount' => 'required|numeric|min:0.01',
            'payment_date' => 'required|date',
            'payment_method' => 'required|in:cash,cash_hand,instapay,bank_transfer',
            'receipt_ref' => 'nullable|string',
            'notes' => 'nullable|string'
        ]);

        $validated['created_by'] = Auth::id();

        $payment = DB::transaction(function () use ($validated, $user) {
            $payment = ClientPayment::create($validated);

            // Update deal paid amount
            $deal = Deal::find($validated['deal_id']);
            if ($deal) {
                $deal->increment('paid_amount', $validated['amount']);
                if ($deal->status === 'pending') {
                    $deal->update(['status' => 'active']);
                }
            }

            // Also record in primary ledger for income tracking
            LedgerEntry::create([
                'date' => $validated['payment_date'],
                'type' => 'income',
                'deal_id' => $deal ? $deal->id : null,
                'client_id' => $validated['client_id'],
                'department_id' => $deal ? $deal->department_id : null,
                'amount' => $validated['amount'],
                'payment_method' => $validated['payment_method'],
                'description' => 'دفعة جزئية للعقد/الصفقة: ' . ($deal ? $deal->title : '') . (!empty($validated['notes']) ? ' - ' . $validated['notes'] : ''),
                'created_by' => Auth::id()
            ]);

            // Record Activity in Deal History
            try {
                $methodNames = [
                    'cash' => 'نقدي (Cash)',
                    'cash_hand' => 'نقداً باليد',
                    'instapay' => 'إنستاباي (InstaPay)',
                    'bank_transfer' => 'تحويل بنكي'
                ];
                $methodLabel = $methodNames[$validated['payment_method']] ?? $validated['payment_method'];

                if ($deal && $user) {
                    DB::table('activity_log')->insert([
                        'log_name' => 'deal',
                        'description' => "تم تسجيل دفعة مالية بقيمة " . number_format($validated['amount'], 2) . " ج.م بواسطة {$user->name} (طريقة التحصيل: {$methodLabel})",
                        'subject_type' => \App\Models\Deal::class,
                        'subject_id' => $deal->id,
                        'causer_type' => \App\Models\User::class,
                        'causer_id' => $user->id,
                        'properties' => json_encode([
                            'title' => 'تسجيل تحصيل مالي',
                            'field' => 'payment',
                            'amount' => (float)$validated['amount'],
                            'payment_method' => $validated['payment_method'],
                            'payment_method_label' => $methodLabel,
                            'receipt_ref' => $validated['receipt_ref'] ?? null,
                            'icon' => 'fa-money-bill-wave',
                            'color' => '#10b981',
                            'causer_name' => $user->name,
                            'causer_role' => $user->role,
                            'causer_email' => $user->email,
                            'created_at_human' => now()->translatedFormat('d M Y - h:i A')
                        ], JSON_UNESCAPED_UNICODE),
                        'created_at' => now(),
                        'updated_at' => now()
                    ]);
                }
            } catch (\Throwable $e) {
                Log::warning('Failed to log deal payment activity: ' . $e->getMessage());
            }

            return $payment;
        });

        return response()->json([
            'status' => 'success',
            'message' => 'تم تسجيل الدفعة وتحديث رصيد العميل بنجاح',
            'data' => $payment->load(['deal', 'client'])
        ], 201);
    }

    // --- Custody Account Management (بند العهدة) ---
    public function getCustodyAccounts()
    {
        $custodyAccounts = CustodyAccount::with(['employee', 'creator'])->latest()->get();
        return response()->json(['status' => 'success', 'data' => $custodyAccounts]);
    }

    public function issueCustody(Request $request)
    {
        $validated = $request->validate([
            'employee_id' => 'required|exists:users,id',
            'issued_amount' => 'required|numeric|min:0.01',
            'notes' => 'nullable|string'
        ]);

        $custody = CustodyAccount::create([
            'employee_id' => $validated['employee_id'],
            'issued_amount' => $validated['issued_amount'],
            'returned_amount' => 0,
            'spent_amount' => $validated['issued_amount'],
            'status' => 'open',
            'notes' => $validated['notes'] ?? null,
            'created_by' => Auth::id()
        ]);

        // Record in ledger as custody_issued
        LedgerEntry::create([
            'date' => now()->toDateString(),
            'type' => 'custody_issued',
            'employee_id' => $validated['employee_id'],
            'amount' => $validated['issued_amount'],
            'payment_method' => 'cash',
            'description' => 'تسليم عهدة للموظف: ' . $custody->employee?->name,
            'created_by' => Auth::id()
        ]);

        return response()->json(['status' => 'success', 'data' => $custody], 201);
    }

    public function returnCustody(Request $request, $id)
    {
        $custody = CustodyAccount::findOrFail($id);
        $validated = $request->validate([
            'returned_amount' => 'required|numeric|min:0',
            'spent_category_id' => 'nullable|exists:finance_categories,id',
            'notes' => 'nullable|string'
        ]);

        $returned = (float) $validated['returned_amount'];
        $issued = (float) $custody->issued_amount;
        $spent = max(0, $issued - $returned);

        $custody->update([
            'returned_amount' => $returned,
            'spent_amount' => $spent,
            'status' => 'settled',
            'notes' => !empty($validated['notes']) ? $custody->notes . ' | ' . $validated['notes'] : $custody->notes

        ]);

        // Log returned custody as income/incoming custody
        if ($returned > 0) {
            LedgerEntry::create([
                'date' => now()->toDateString(),
                'type' => 'custody_returned',
                'employee_id' => $custody->employee_id,
                'amount' => $returned,
                'payment_method' => 'cash',
                'description' => 'استلام المتبقي من العهدة من الموظف: ' . $custody->employee?->name,
                'created_by' => Auth::id()
            ]);
        }

        // Log net spent amount as expense
        if ($spent > 0) {
            $notesSuffix = !empty($validated['notes']) ? ' | البيان والملاحظات: ' . $validated['notes'] : '';
            LedgerEntry::create([
                'date' => now()->toDateString(),
                'type' => 'expense',
                'category_id' => $validated['spent_category_id'] ?? null,
                'employee_id' => $custody->employee_id,
                'amount' => $spent,
                'payment_method' => 'cash',
                'description' => 'مصروف العهدة الفعلي للموظف: ' . $custody->employee?->name . $notesSuffix,
                'created_by' => Auth::id()
            ]);
        }

        return response()->json(['status' => 'success', 'message' => 'تم تسوية العهدة بنجاح', 'data' => $custody]);
    }

    // --- Partner Profit Split Report ---
    public function getPartnerProfitSplitReport()
    {
        $partneredDepts = Department::where('has_partner', true)->get();
        $report = [];

        foreach ($partneredDepts as $dept) {
            // Direct ledger income assigned to department
            $ledgerIncome = (float) LedgerEntry::where('department_id', $dept->id)->where('type', 'income')->sum('amount');

            // Deals belonging to this department
            $dealIds = Deal::where('department_id', $dept->id)->pluck('id');
            $dealPaymentsIncome = (float) ClientPayment::whereIn('deal_id', $dealIds)->sum('amount');

            // Tasks created directly for this department
            $deptTasksIncome = (float) Task::where('department_id', $dept->id)->where('status', '!=', 'cancelled')->sum('client_price');

            // Total department gross revenue
            $income = max($ledgerIncome, $dealPaymentsIncome, $deptTasksIncome);

            // Department Direct Expenses
            $ledgerExpenses = (float) LedgerEntry::where('department_id', $dept->id)->where('type', 'expense')->sum('amount');
            $deptTaskCosts = (float) Task::where('department_id', $dept->id)->where('status', '!=', 'cancelled')->sum('employee_price');

            $expenses = $ledgerExpenses + $deptTaskCosts;

            $netProfit = max(0, $income - $expenses);

            $partnerPct = (float) $dept->partner_percentage;
            $partnerShare = ($netProfit * $partnerPct) / 100;
            $companyShare = $netProfit - $partnerShare;

            $report[] = [
                'department_id' => $dept->id,
                'department_name' => $dept->name,
                'partner_name' => $dept->partner_name,
                'partner_percentage' => $partnerPct,
                'company_percentage' => 100 - $partnerPct,
                'total_income' => (float) $income,
                'total_expenses' => (float) $expenses,
                'net_profit' => (float) $netProfit,
                'partner_share' => (float) $partnerShare,
                'company_share' => (float) $companyShare
            ];
        }

        return response()->json(['status' => 'success', 'data' => $report]);
    }

    // --- Fixed Assets Management ---
    public function getFixedAssets()
    {
        $assets = FixedAsset::with('department')->latest()->get();
        return response()->json(['status' => 'success', 'data' => $assets]);
    }

    public function storeFixedAsset(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'value' => 'required|numeric|min:0',
            'purchase_date' => 'nullable|date',
            'department_id' => 'nullable|exists:departments,id',
            'is_partnered_asset' => 'boolean',
            'notes' => 'nullable|string'
        ]);

        $asset = FixedAsset::create($validated);
        return response()->json(['status' => 'success', 'data' => $asset], 201);
    }

    // --- Payroll & Employee Calculations (Hybrid formula) ---
    public function getPayrollSummary(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->canAccessFinance()) {
            return response()->json(['message' => 'غير مصرح لك بالاطلاع على مسيرات الرواتب والمستحقات'], 403);
        }

        $month = $request->get('month', now()->month);
        $year = $request->get('year', now()->year);

        $empQuery = User::whereIn('role', ['employee', 'department_manager', 'manager', 'sales', 'admin', 'super_admin', 'account_manager']);

        if ($request->filled('employee_id')) {
            $empQuery->where('id', $request->employee_id);
        }

        $employees = $empQuery->get();
        $payrollList = [];

        $fromDate = $request->get('from_date');
        $toDate = $request->get('to_date');

        foreach ($employees as $employee) {
            $paymentType = $employee->payment_type ?? 'salary_based';
            $baseSalary = (float) $employee->base_salary;

            // Task earnings for task_based or hybrid
            $taskEarnings = 0;
            $tQuery = $employee->tasks()->whereIn('status', ['done', 'approved', 'completed']);

            if ($fromDate) {
                $tQuery->whereDate('updated_at', '>=', $fromDate);
            }
            if ($toDate) {
                $tQuery->whereDate('updated_at', '<=', $toDate);
            }

            $completedTasks = $tQuery->with('deal')->get();
            foreach ($completedTasks as $t) {
                $taskEarnings += (float) ($t->employee_price ?? $t->client_price ?? 0);
            }

            // Commission earnings
            $commissionEarnings = 0;
            if (in_array($paymentType, ['percentage_based', 'hybrid', 'commission'])) {
                $dQuery = Deal::where('sales_person_id', $employee->id);
                if ($fromDate) {
                    $dQuery->whereDate('created_at', '>=', $fromDate);
                }
                if ($toDate) {
                    $dQuery->whereDate('created_at', '<=', $toDate);
                }
                $salesDeals = $dQuery->get();
                foreach ($salesDeals as $d) {
                    if ($d->sales_commission_type === 'percentage') {
                        $commissionEarnings += ($d->calculated_total * (float) $d->sales_commission_value) / 100;
                    } elseif ($d->sales_commission_type === 'fixed') {
                        $commissionEarnings += (float) $d->sales_commission_value;
                    }
                }
            }

            // Advances, Deductions, Bonuses from ledger
            $lQuery = LedgerEntry::where('employee_id', $employee->id);
            if ($fromDate) {
                $lQuery->whereDate('date', '>=', $fromDate);
            }
            if ($toDate) {
                $lQuery->whereDate('date', '<=', $toDate);
            }

            $advances = (clone $lQuery)->where('type', 'expense')->whereHas('category', function($q) { $q->where('name_ar', 'like', '%سلف%'); })->sum('amount');
            $deductions = (clone $lQuery)->where('type', 'expense')->whereHas('category', function($q) { $q->where('name_ar', 'like', '%خصومات%'); })->sum('amount');
            $bonuses = (clone $lQuery)->where('type', 'expense')->whereHas('category', function($q) { $q->where('name_ar', 'like', '%مكافآت%')->orWhere('name_ar', 'like', '%حوافز%'); })->sum('amount');

            // Custody issued & returned
            $custodyIssued = CustodyAccount::where('employee_id', $employee->id)->sum('issued_amount');
            $custodyReturned = CustodyAccount::where('employee_id', $employee->id)->sum('returned_amount');

            $netPayable = max(0, $baseSalary + $taskEarnings + $commissionEarnings - $advances - $deductions + $bonuses);

            $payrollList[] = [
                'employee_id' => $employee->id,
                'employee_name' => $employee->name,
                'employee_email' => $employee->email,
                'employee_phone' => $employee->phone,
                'department_name' => $employee->department?->name ?? 'العامة',
                'payment_type' => $paymentType,
                'month' => (int) $month,
                'year' => (int) $year,
                'base_salary' => $baseSalary,
                'task_earnings' => (float) $taskEarnings,
                'commission_earnings' => (float) $commissionEarnings,
                'advances' => (float) $advances,
                'deductions' => (float) $deductions,
                'bonuses' => (float) $bonuses,
                'custody_issued' => (float) $custodyIssued,
                'custody_returned' => (float) $custodyReturned,
                'net_payable' => (float) $netPayable,
                'tasks_count' => $completedTasks->count(),
                'tasks_list' => $completedTasks->map(function($t) {
                    return [
                        'id' => $t->id,
                        'title' => $t->title,
                        'status' => $t->status,
                        'deal_title' => $t->deal?->title ?? 'مستقلة',
                        'price' => (float) ($t->employee_price ?? $t->client_price ?? 0),
                        'date' => $t->updated_at ? $t->updated_at->format('Y-m-d') : null
                    ];
                })
            ];
        }

        return response()->json(['status' => 'success', 'data' => $payrollList]);
    }
}
